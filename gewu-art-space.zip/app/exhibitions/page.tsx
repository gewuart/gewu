import Link from "next/link"
import Image from "next/image"
import { Calendar, MapPin, Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"

export default function ExhibitionsPage() {
  return (
    <div className="container mx-auto py-8 px-4 md:px-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">画展资讯</h1>
          <p className="text-gray-500">了解最新的艺术展览和活动信息</p>
        </div>
        <div className="flex items-center gap-2 w-full md:w-auto">
          <div className="relative w-full md:w-auto">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
            <Input type="search" placeholder="搜索展览..." className="pl-8 w-full md:w-[250px]" />
          </div>
        </div>
      </div>

      <Tabs defaultValue="upcoming" className="mb-8">
        <TabsList className="mb-4">
          <TabsTrigger value="upcoming">即将开展</TabsTrigger>
          <TabsTrigger value="ongoing">正在展出</TabsTrigger>
          <TabsTrigger value="past">往期展览</TabsTrigger>
        </TabsList>
        <TabsContent value="upcoming">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {exhibitions
              .filter((exhibition) => exhibition.status === "upcoming")
              .map((exhibition) => (
                <ExhibitionCard key={exhibition.id} exhibition={exhibition} />
              ))}
          </div>
        </TabsContent>
        <TabsContent value="ongoing">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {exhibitions
              .filter((exhibition) => exhibition.status === "ongoing")
              .map((exhibition) => (
                <ExhibitionCard key={exhibition.id} exhibition={exhibition} />
              ))}
          </div>
        </TabsContent>
        <TabsContent value="past">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {exhibitions
              .filter((exhibition) => exhibition.status === "past")
              .map((exhibition) => (
                <ExhibitionCard key={exhibition.id} exhibition={exhibition} />
              ))}
          </div>
        </TabsContent>
      </Tabs>

      <Separator className="my-8" />

      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-6">热门城市展览</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {cities.map((city, index) => (
            <Link key={index} href={`/exhibitions/city/${city.slug}`} className="group">
              <div className="relative h-32 rounded-lg overflow-hidden">
                <Image
                  src={city.image || "/placeholder.svg"}
                  alt={city.name}
                  fill
                  className="object-cover transition-transform group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                  <h3 className="text-white font-bold text-xl">{city.name}</h3>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-bold mb-6">艺术活动日历</h2>
        <div className="bg-gray-50 p-6 rounded-lg">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {events.map((event, index) => (
              <div key={index} className="bg-white p-4 rounded-lg shadow-sm border border-gray-100">
                <div className="flex items-start gap-4">
                  <div className="bg-gray-100 rounded p-2 text-center min-w-[60px]">
                    <div className="text-sm font-medium text-gray-500">{event.month}</div>
                    <div className="text-2xl font-bold">{event.day}</div>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">{event.title}</h3>
                    <div className="flex items-center text-sm text-gray-500 mb-1">
                      <Calendar className="h-3 w-3 mr-1" />
                      <span>{event.time}</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-500">
                      <MapPin className="h-3 w-3 mr-1" />
                      <span>{event.location}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6 text-center">
            <Button variant="outline">查看更多活动</Button>
          </div>
        </div>
      </section>
    </div>
  )
}

function ExhibitionCard({ exhibition }) {
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <div className="relative">
        <Image
          src={exhibition.image || "/placeholder.svg"}
          alt={exhibition.title}
          width={600}
          height={400}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-2 left-2">
          {exhibition.status === "upcoming" && <Badge className="bg-blue-500 hover:bg-blue-600">即将开展</Badge>}
          {exhibition.status === "ongoing" && <Badge className="bg-green-500 hover:bg-green-600">正在展出</Badge>}
          {exhibition.status === "past" && (
            <Badge variant="outline" className="bg-white/80">
              已结束
            </Badge>
          )}
        </div>
      </div>
      <CardHeader className="p-4 pb-2">
        <CardTitle className="text-lg">{exhibition.title}</CardTitle>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <div className="flex items-center text-sm text-gray-500 mb-2">
          <Calendar className="h-4 w-4 mr-2" />
          <span>{exhibition.date}</span>
        </div>
        <div className="flex items-center text-sm text-gray-500 mb-4">
          <MapPin className="h-4 w-4 mr-2" />
          <span>{exhibition.location}</span>
        </div>
        <p className="text-sm text-gray-600 line-clamp-2">{exhibition.description}</p>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex justify-between items-center">
        {exhibition.ticketPrice ? (
          <span className="font-medium">票价: ¥{exhibition.ticketPrice}</span>
        ) : (
          <span className="font-medium text-green-600">免费入场</span>
        )}
        <Button size="sm">查看详情</Button>
      </CardFooter>
    </Card>
  )
}

// Sample data
const exhibitions = [
  {
    id: "1",
    title: "山水之间：当代中国山水画展",
    description: "本次展览汇集了30位当代中国艺术家的山水画作品，展示了传统山水画在当代语境下的创新与发展。",
    date: "2023年6月1日 - 2023年7月15日",
    location: "北京 · 中央美术学院美术馆",
    image: "/placeholder.svg?height=400&width=600",
    status: "upcoming",
    ticketPrice: "80",
  },
  {
    id: "2",
    title: "色彩的交响：现代油画艺术展",
    description: "展出来自国内外20位艺术家的油画作品，探索色彩在现代油画中的表现力和情感传达。",
    date: "2023年5月20日 - 2023年8月20日",
    location: "上海 · 当代艺术博物馆",
    image: "/placeholder.svg?height=400&width=600",
    status: "ongoing",
    ticketPrice: "100",
  },
  {
    id: "3",
    title: "传统与创新：青年艺术家联展",
    description: "展示50位35岁以下青年艺术家的作品，涵盖绘画、雕塑、装置等多种媒介，展现新一代艺术家的创作活力。",
    date: "2023年7月1日 - 2023年8月30日",
    location: "杭州 · 中国美术学院美术馆",
    image: "/placeholder.svg?height=400&width=600",
    status: "upcoming",
    ticketPrice: null,
  },
  {
    id: "4",
    title: "数字艺术与未来：沉浸式体验展",
    description: "结合最新数字技术和艺术创作，打造沉浸式艺术体验空间，探索艺术的未来发展方向。",
    date: "2023年4月15日 - 2023年6月15日",
    location: "深圳 · 当代艺术与城市规划馆",
    image: "/placeholder.svg?height=400&width=600",
    status: "ongoing",
    ticketPrice: "120",
  },
  {
    id: "5",
    title: "东方美学：亚洲传统工艺展",
    description: "展示来自中国、日本、韩国等亚洲国家的传统工艺作品，包括陶瓷、漆器、织物等。",
    date: "2023年3月10日 - 2023年5月10日",
    location: "南京 · 博物院",
    image: "/placeholder.svg?height=400&width=600",
    status: "past",
    ticketPrice: "60",
  },
  {
    id: "6",
    title: "光影魔术：摄影艺术百年回顾展",
    description: "回顾摄影艺术百年发展历程，展出国内外经典摄影作品200余幅。",
    date: "2023年2月1日 - 2023年4月30日",
    location: "广州 · 摄影艺术馆",
    image: "/placeholder.svg?height=400&width=600",
    status: "past",
    ticketPrice: "50",
  },
]

const cities = [
  { name: "北京", image: "/placeholder.svg?height=200&width=300", slug: "beijing" },
  { name: "上海", image: "/placeholder.svg?height=200&width=300", slug: "shanghai" },
  { name: "广州", image: "/placeholder.svg?height=200&width=300", slug: "guangzhou" },
  { name: "深圳", image: "/placeholder.svg?height=200&width=300", slug: "shenzhen" },
  { name: "杭州", image: "/placeholder.svg?height=200&width=300", slug: "hangzhou" },
  { name: "成都", image: "/placeholder.svg?height=200&width=300", slug: "chengdu" },
]

const events = [
  {
    title: "艺术家讲座：当代水墨的创新",
    month: "6月",
    day: "15",
    time: "14:00 - 16:00",
    location: "北京 · 格物艺术空间",
  },
  {
    title: "油画技法工作坊",
    month: "6月",
    day: "20",
    time: "10:00 - 17:00",
    location: "上海 · 格物艺术空间",
  },
  {
    title: "艺术市场与收藏讲座",
    month: "6月",
    day: "25",
    time: "19:00 - 21:00",
    location: "线上直播",
  },
  {
    title: "儿童创意绘画比赛",
    month: "7月",
    day: "1",
    time: "9:00 - 12:00",
    location: "杭州 · 西湖艺术中心",
  },
  {
    title: "版画制作体验活动",
    month: "7月",
    day: "8",
    time: "13:00 - 17:00",
    location: "广州 · 格物艺术空间",
  },
  {
    title: "艺术电影放映周",
    month: "7月",
    day: "15",
    time: "每天19:00",
    location: "全国各格物艺术空间",
  },
]

