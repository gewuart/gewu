import Link from "next/link"
import { FileText, Image, Users, ShoppingBag, Calendar, Settings } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function AdminDashboard() {
  return (
    <div className="container mx-auto py-8 px-4 md:px-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">管理后台</h1>
          <p className="text-gray-500">管理您的课程、素材、商品和展览信息</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>课程管理</CardTitle>
            <CardDescription>管理在线课程内容</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-2">
              <Button asChild variant="outline" className="justify-start">
                <Link href="/admin/courses">
                  <FileText className="mr-2 h-4 w-4" />
                  查看所有课程
                </Link>
              </Button>
              <Button asChild className="justify-start">
                <Link href="/admin/upload">
                  <FileText className="mr-2 h-4 w-4" />
                  上传新课程
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle>素材管理</CardTitle>
            <CardDescription>管理绘画素材库</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-2">
              <Button asChild variant="outline" className="justify-start">
                <Link href="/admin/resources">
                  <Image className="mr-2 h-4 w-4" />
                  查看所有素材
                </Link>
              </Button>
              <Button asChild className="justify-start">
                <Link href="/admin/resources/upload">
                  <Image className="mr-2 h-4 w-4" />
                  上传新素材
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle>商品管理</CardTitle>
            <CardDescription>管理画材商城商品</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-2">
              <Button asChild variant="outline" className="justify-start">
                <Link href="/admin/products">
                  <ShoppingBag className="mr-2 h-4 w-4" />
                  查看所有商品
                </Link>
              </Button>
              <Button asChild className="justify-start">
                <Link href="/admin/products/add">
                  <ShoppingBag className="mr-2 h-4 w-4" />
                  添加新商品
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle>展览管理</CardTitle>
            <CardDescription>管理画展资讯</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-2">
              <Button asChild variant="outline" className="justify-start">
                <Link href="/admin/exhibitions">
                  <Calendar className="mr-2 h-4 w-4" />
                  查看所有展览
                </Link>
              </Button>
              <Button asChild className="justify-start">
                <Link href="/admin/exhibitions/add">
                  <Calendar className="mr-2 h-4 w-4" />
                  添加新展览
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle>艺术家管理</CardTitle>
            <CardDescription>管理艺术家信息</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-2">
              <Button asChild variant="outline" className="justify-start">
                <Link href="/admin/artists">
                  <Users className="mr-2 h-4 w-4" />
                  查看所有艺术家
                </Link>
              </Button>
              <Button asChild className="justify-start">
                <Link href="/admin/artists/add">
                  <Users className="mr-2 h-4 w-4" />
                  添加新艺术家
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle>系统设置</CardTitle>
            <CardDescription>管理网站设置</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-2">
              <Button asChild variant="outline" className="justify-start">
                <Link href="/admin/settings">
                  <Settings className="mr-2 h-4 w-4" />
                  网站设置
                </Link>
              </Button>
              <Button asChild variant="outline" className="justify-start">
                <Link href="/admin/users">
                  <Users className="mr-2 h-4 w-4" />
                  用户管理
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

