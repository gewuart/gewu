"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Upload, X } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"

export default function UploadPage() {
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [category, setCategory] = useState("")
  const [price, setPrice] = useState("")
  const [instructor, setInstructor] = useState("")
  const [level, setLevel] = useState("")
  const [thumbnail, setThumbnail] = useState<File | null>(null)
  const [video, setVideo] = useState<File | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [thumbnailPreview, setThumbnailPreview] = useState<string | null>(null)

  const router = useRouter()
  const { toast } = useToast()

  const handleThumbnailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]
      setThumbnail(file)

      // Create preview URL
      const reader = new FileReader()
      reader.onload = (event) => {
        setThumbnailPreview(event.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setVideo(e.target.files[0])
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!title || !description || !category || !price || !instructor || !level || !thumbnail) {
      toast({
        title: "请填写所有必填字段",
        description: "请确保填写了所有必填信息并上传了缩略图",
        variant: "destructive",
      })
      return
    }

    setIsUploading(true)

    // 这里是模拟上传，实际项目中需要连接到后端API
    try {
      // 创建FormData对象用于文件上传
      const formData = new FormData()
      formData.append("title", title)
      formData.append("description", description)
      formData.append("category", category)
      formData.append("price", price)
      formData.append("instructor", instructor)
      formData.append("level", level)
      if (thumbnail) formData.append("thumbnail", thumbnail)
      if (video) formData.append("video", video)

      // 模拟API请求延迟
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // 实际项目中，这里应该是真实的API请求
      // const response = await fetch("/api/courses", {
      //   method: "POST",
      //   body: formData
      // })

      // if (!response.ok) throw new Error("上传失败")

      toast({
        title: "上传成功",
        description: "课程已成功上传到系统",
      })

      // 重置表单
      setTitle("")
      setDescription("")
      setCategory("")
      setPrice("")
      setInstructor("")
      setLevel("")
      setThumbnail(null)
      setVideo(null)
      setThumbnailPreview(null)

      // 可选：上传成功后跳转到课程列表页
      // router.push("/admin/courses")
    } catch (error) {
      toast({
        title: "上传失败",
        description: "上传过程中发生错误，请稍后重试",
        variant: "destructive",
      })
    } finally {
      setIsUploading(false)
    }
  }

  return (
    <div className="container mx-auto py-8 px-4 md:px-6">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">上传课程</h1>

        <form onSubmit={handleSubmit}>
          <Card>
            <CardHeader>
              <CardTitle>课程信息</CardTitle>
              <CardDescription>请填写课程的详细信息和上传相关文件</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">课程标题 *</Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="例如：水彩风景入门"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">课程描述 *</Label>
                <Textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="详细描述课程内容和学习目标"
                  rows={4}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="category">课程分类 *</Label>
                  <Select value={category} onValueChange={setCategory} required>
                    <SelectTrigger id="category">
                      <SelectValue placeholder="选择分类" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="watercolor">水彩</SelectItem>
                      <SelectItem value="oil-painting">油画</SelectItem>
                      <SelectItem value="sketch">素描</SelectItem>
                      <SelectItem value="chinese-painting">国画</SelectItem>
                      <SelectItem value="illustration">插画</SelectItem>
                      <SelectItem value="sculpture">雕塑</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="price">课程价格 (¥) *</Label>
                  <Input
                    id="price"
                    type="number"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    placeholder="299"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="instructor">讲师姓名 *</Label>
                  <Input
                    id="instructor"
                    value={instructor}
                    onChange={(e) => setInstructor(e.target.value)}
                    placeholder="例如：李明"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="level">课程难度 *</Label>
                  <Select value={level} onValueChange={setLevel} required>
                    <SelectTrigger id="level">
                      <SelectValue placeholder="选择难度" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beginner">入门</SelectItem>
                      <SelectItem value="intermediate">进阶</SelectItem>
                      <SelectItem value="advanced">高级</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="thumbnail">课程缩略图 *</Label>
                <div className="flex items-center gap-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => document.getElementById("thumbnail")?.click()}
                    className="w-full h-32 border-dashed flex flex-col items-center justify-center"
                  >
                    {thumbnailPreview ? (
                      <div className="relative w-full h-full">
                        <img
                          src={thumbnailPreview || "/placeholder.svg"}
                          alt="缩略图预览"
                          className="w-full h-full object-cover"
                        />
                        <Button
                          type="button"
                          variant="destructive"
                          size="icon"
                          className="absolute top-1 right-1 h-6 w-6"
                          onClick={(e) => {
                            e.stopPropagation()
                            setThumbnail(null)
                            setThumbnailPreview(null)
                          }}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ) : (
                      <>
                        <Upload className="h-8 w-8 mb-2 text-gray-400" />
                        <span className="text-sm text-gray-500">点击上传缩略图</span>
                      </>
                    )}
                  </Button>
                  <input
                    id="thumbnail"
                    type="file"
                    accept="image/*"
                    onChange={handleThumbnailChange}
                    className="hidden"
                  />
                </div>
                <p className="text-xs text-gray-500">推荐尺寸: 600 x 400 像素, 最大文件大小: 2MB</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="video">课程视频 (可选)</Label>
                <div className="flex items-center gap-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => document.getElementById("video")?.click()}
                    className="w-full py-8 border-dashed flex flex-col items-center justify-center"
                  >
                    <Upload className="h-8 w-8 mb-2 text-gray-400" />
                    <span className="text-sm text-gray-500">{video ? `已选择: ${video.name}` : "点击上传视频"}</span>
                  </Button>
                  <input id="video" type="file" accept="video/*" onChange={handleVideoChange} className="hidden" />
                </div>
                <p className="text-xs text-gray-500">支持MP4格式, 最大文件大小: 500MB</p>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button type="button" variant="outline" onClick={() => router.back()}>
                取消
              </Button>
              <Button type="submit" disabled={isUploading}>
                {isUploading ? "上传中..." : "上传课程"}
              </Button>
            </CardFooter>
          </Card>
        </form>
      </div>
    </div>
  )
}

