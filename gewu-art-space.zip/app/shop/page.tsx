import Link from "next/link"
import Image from "next/image"
import { Filter, Search, ShoppingCart } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"

export default function ShopPage() {
  return (
    <div className="container mx-auto py-12 px-4 md:px-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl md:text-4xl font-bold mb-2 text-gray-800">物品堂</h1>
          <p className="text-gray-500">精选国内外高品质画材和工具</p>
        </div>
        <div className="flex items-center gap-2 w-full md:w-auto">
          <div className="relative w-full md:w-auto">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
            <Input type="search" placeholder="搜索商品..." className="pl-8 w-full md:w-[250px]" />
          </div>
          <Button variant="outline" size="icon" className="border-pastel-pink text-pastel-pink">
            <Filter className="h-4 w-4" />
            <span className="sr-only">筛选</span>
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" className="mb-8">
        <TabsList className="mb-6 bg-transparent p-0 h-auto space-x-2 flex overflow-x-auto no-scrollbar justify-start md:justify-center">
          <TabsTrigger
            value="all"
            className="data-[state=active]:bg-pastel-pink data-[state=active]:text-white rounded-full px-6 py-2"
          >
            全部商品
          </TabsTrigger>
          <TabsTrigger
            value="paint"
            className="data-[state=active]:bg-pastel-purple data-[state=active]:text-white rounded-full px-6 py-2"
          >
            颜料
          </TabsTrigger>
          <TabsTrigger
            value="brush"
            className="data-[state=active]:bg-pastel-blue data-[state=active]:text-white rounded-full px-6 py-2"
          >
            画笔
          </TabsTrigger>
          <TabsTrigger
            value="paper"
            className="data-[state=active]:bg-pastel-mint data-[state=active]:text-white rounded-full px-6 py-2"
          >
            纸张
          </TabsTrigger>
          <TabsTrigger
            value="tools"
            className="data-[state=active]:bg-pastel-yellow data-[state=active]:text-white rounded-full px-6 py-2"
          >
            工具
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="paint">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {products
              .filter((product) => product.category === "颜料")
              .map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="brush">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {products
              .filter((product) => product.category === "画笔")
              .map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="paper">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {products
              .filter((product) => product.category === "纸张")
              .map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="tools">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {products
              .filter((product) => product.category === "工具")
              .map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
          </div>
        </TabsContent>
      </Tabs>

      <Separator className="my-12" />

      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-6 text-gray-800">热门品牌</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {brands.map((brand, index) => (
            <Link key={index} href={`/shop/brand/${brand.slug}`} className="group">
              <div className="bg-white rounded-lg p-4 text-center border border-gray-200 transition-all hover:border-pastel-pink hover:shadow-sm">
                <Image
                  src={brand.logo || "/placeholder.svg"}
                  alt={brand.name}
                  width={120}
                  height={60}
                  className="h-12 w-auto mx-auto object-contain"
                />
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-bold mb-6 text-gray-800">购物保障</h2>
        <div className="grid md:grid-cols-4 gap-8">
          <div className="bg-pastel-pink/10 p-6 rounded-2xl text-center">
            <div className="text-4xl mb-4 mx-auto">🛒</div>
            <h3 className="text-xl font-semibold mb-2 text-gray-800">正品保障</h3>
            <p className="text-gray-600">所有商品均为原装正品，品质有保障</p>
          </div>
          <div className="bg-pastel-purple/10 p-6 rounded-2xl text-center">
            <div className="text-4xl mb-4 mx-auto">🚚</div>
            <h3 className="text-xl font-semibold mb-2 text-gray-800">快速配送</h3>
            <p className="text-gray-600">全国大部分地区48小时内发货</p>
          </div>
          <div className="bg-pastel-blue/10 p-6 rounded-2xl text-center">
            <div className="text-4xl mb-4 mx-auto">🔄</div>
            <h3 className="text-xl font-semibold mb-2 text-gray-800">无忧退换</h3>
            <p className="text-gray-600">7天无理由退换，15天质量问题包退</p>
          </div>
          <div className="bg-pastel-mint/10 p-6 rounded-2xl text-center">
            <div className="text-4xl mb-4 mx-auto">💬</div>
            <h3 className="text-xl font-semibold mb-2 text-gray-800">专业咨询</h3>
            <p className="text-gray-600">专业画材顾问在线解答各类问题</p>
          </div>
        </div>
      </section>
    </div>
  )
}

function ProductCard({ product }) {
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow h-full group">
      <div className="relative">
        <Image
          src={product.image || "/placeholder.svg"}
          alt={product.title}
          width={400}
          height={400}
          className="w-full h-48 object-contain bg-white p-4 group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-2 left-2">
          <Badge
            className={`
            ${product.category === "颜料" ? "bg-pastel-purple" : ""}
            ${product.category === "画笔" ? "bg-pastel-blue" : ""}
            ${product.category === "纸张" ? "bg-pastel-mint" : ""}
            ${product.category === "工具" ? "bg-pastel-yellow" : ""}
            text-white rounded-full px-3 py-1
          `}
          >
            {product.category}
          </Badge>
        </div>
        {product.discount && (
          <div className="absolute top-2 right-2">
            <Badge className="bg-pastel-pink text-white rounded-full px-3 py-1">-{product.discount}%</Badge>
          </div>
        )}
      </div>
      <CardHeader className="p-4 pb-2">
        <CardTitle className="text-lg text-gray-800 group-hover:text-pastel-pink transition-colors">
          {product.title}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <p className="text-sm text-gray-600 line-clamp-2">{product.description}</p>
        <div className="mt-2 flex items-center">
          {product.discount ? (
            <div className="flex items-center">
              <span className="font-bold text-lg text-pastel-pink">¥{product.discountPrice}</span>
              <span className="ml-2 text-sm text-gray-500 line-through">¥{product.price}</span>
            </div>
          ) : (
            <span className="font-bold text-lg text-pastel-pink">¥{product.price}</span>
          )}
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex justify-between items-center">
        <div className="flex items-center text-sm">
          <span className="text-yellow-500">★★★★★</span>
          <span className="ml-1">{product.rating}</span>
          <span className="mx-1">|</span>
          <span>已售{product.sold}件</span>
        </div>
        <Button className="bg-pastel-pink/10 text-pastel-pink hover:bg-pastel-pink/20 rounded-full">
          <ShoppingCart className="h-4 w-4 mr-2" />
          加入购物车
        </Button>
      </CardFooter>
    </Card>
  )
}

// Sample data
const products = [
  {
    id: "1",
    title: "Windsor & Newton专业水彩颜料24色",
    description: "英国温莎牛顿专业水彩颜料，24色套装，色彩鲜艳，透明度高。",
    price: "899",
    discountPrice: "799",
    discount: 10,
    image: "/placeholder.svg?height=400&width=400",
    category: "颜料",
    rating: "4.9",
    sold: "1,245",
  },
  {
    id: "2",
    title: "Da Vinci顶级水彩画笔套装",
    description: "德国达芬奇顶级水彩画笔，纯松鼠毛，吸水性强，弹性好。",
    price: "699",
    discountPrice: null,
    discount: null,
    image: "/placeholder.svg?height=400&width=400",
    category: "画笔",
    rating: "4.8",
    sold: "876",
  },
  {
    id: "3",
    title: "Arches法国进口水彩纸300g",
    description: "法国阿诗水彩纸，300g/㎡，100%棉，冷压纹理，适合专业水彩创作。",
    price: "199",
    discountPrice: "159",
    discount: 20,
    image: "/placeholder.svg?height=400&width=400",
    category: "纸张",
    rating: "4.9",
    sold: "2,134",
  },
  {
    id: "4",
    title: "Schmincke德国进口油画颜料套装",
    description: "德国施密特油画颜料，12色套装，颜料细腻，着色力强。",
    price: "1299",
    discountPrice: null,
    discount: null,
    image: "/placeholder.svg?height=400&width=400",
    category: "颜料",
    rating: "4.7",
    sold: "543",
  },
  {
    id: "5",
    title: "马利国画颜料12色套装",
    description: "马利牌国画颜料，12色套装，色彩纯正，适合中国画创作。",
    price: "199",
    discountPrice: "169",
    discount: 15,
    image: "/placeholder.svg?height=400&width=400",
    category: "颜料",
    rating: "4.6",
    sold: "1,876",
  },
  {
    id: "6",
    title: "樱花素描铅笔套装",
    description: "日本樱花素描铅笔套装，12支装，硬度从2H到8B，线条流畅。",
    price: "89",
    discountPrice: null,
    discount: null,
    image: "/placeholder.svg?height=400&width=400",
    category: "工具",
    rating: "4.8",
    sold: "3,245",
  },
  {
    id: "7",
    title: "云龙宣纸100张装",
    description: "安徽宣纸，传统工艺制作，适合中国画和书法创作。",
    price: "299",
    discountPrice: "249",
    discount: 15,
    image: "/placeholder.svg?height=400&width=400",
    category: "纸张",
    rating: "4.9",
    sold: "987",
  },
  {
    id: "8",
    title: "高级木制画架",
    description: "榉木制作的专业画架，稳固耐用，高度可调节，适合油画和水彩创作。",
    price: "599",
    discountPrice: null,
    discount: null,
    image: "/placeholder.svg?height=400&width=400",
    category: "工具",
    rating: "4.7",
    sold: "432",
  },
]

const brands = [
  { name: "Windsor & Newton", logo: "/placeholder.svg?height=60&width=120", slug: "windsor-newton" },
  { name: "Schmincke", logo: "/placeholder.svg?height=60&width=120", slug: "schmincke" },
  { name: "Da Vinci", logo: "/placeholder.svg?height=60&width=120", slug: "da-vinci" },
  { name: "Arches", logo: "/placeholder.svg?height=60&width=120", slug: "arches" },
  { name: "马利", logo: "/placeholder.svg?height=60&width=120", slug: "marie" },
  { name: "樱花", logo: "/placeholder.svg?height=60&width=120", slug: "sakura" },
]

