import Link from "next/link"
import Image from "next/image"
import { Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"

export default function ArtistsPage() {
  return (
    <div className="container mx-auto py-8 px-4 md:px-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">艺术家</h1>
          <p className="text-gray-500">探索优秀艺术家的作品和创作理念</p>
        </div>
        <div className="flex items-center gap-2 w-full md:w-auto">
          <div className="relative w-full md:w-auto">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
            <Input type="search" placeholder="搜索艺术家..." className="pl-8 w-full md:w-[250px]" />
          </div>
        </div>
      </div>

      <Tabs defaultValue="all" className="mb-8">
        <TabsList className="mb-4">
          <TabsTrigger value="all">全部</TabsTrigger>
          <TabsTrigger value="painting">绘画</TabsTrigger>
          <TabsTrigger value="sculpture">雕塑</TabsTrigger>
          <TabsTrigger value="photography">摄影</TabsTrigger>
          <TabsTrigger value="digital">数字艺术</TabsTrigger>
        </TabsList>
        <TabsContent value="all">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {artists.map((artist) => (
              <ArtistCard key={artist.id} artist={artist} />
            ))}
          </div>
        </TabsContent>
        <TabsContent value="painting">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {artists
              .filter((artist) => artist.category === "绘画")
              .map((artist) => (
                <ArtistCard key={artist.id} artist={artist} />
              ))}
          </div>
        </TabsContent>
        <TabsContent value="sculpture">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {artists
              .filter((artist) => artist.category === "雕塑")
              .map((artist) => (
                <ArtistCard key={artist.id} artist={artist} />
              ))}
          </div>
        </TabsContent>
        <TabsContent value="photography">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {artists
              .filter((artist) => artist.category === "摄影")
              .map((artist) => (
                <ArtistCard key={artist.id} artist={artist} />
              ))}
          </div>
        </TabsContent>
        <TabsContent value="digital">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {artists
              .filter((artist) => artist.category === "数字艺术")
              .map((artist) => (
                <ArtistCard key={artist.id} artist={artist} />
              ))}
          </div>
        </TabsContent>
      </Tabs>

      <Separator className="my-8" />

      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-6">艺术流派</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {artStyles.map((style, index) => (
            <Link key={index} href={`/artists/style/${style.slug}`} className="group">
              <div className="bg-gray-50 rounded-lg p-4 text-center transition-all hover:bg-gray-100 hover:shadow-sm">
                <h3 className="font-medium">{style.name}</h3>
                <p className="text-sm text-gray-500">{style.count}位艺术家</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-bold mb-6">艺术家访谈</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {interviews.map((interview, index) => (
            <Card key={index} className="overflow-hidden hover:shadow-md transition-shadow">
              <div className="relative">
                <Image
                  src={interview.image || "/placeholder.svg"}
                  alt={interview.title}
                  width={600}
                  height={400}
                  className="w-full h-48 object-cover"
                />
                <div className="absolute top-2 left-2">
                  <Badge className="bg-black/70 hover:bg-black/70">访谈</Badge>
                </div>
              </div>
              <CardHeader className="p-4 pb-2">
                <CardTitle className="text-lg">{interview.title}</CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <p className="text-sm text-gray-600 line-clamp-2">{interview.description}</p>
              </CardContent>
              <CardFooter className="p-4 pt-0">
                <Button variant="outline" size="sm" className="ml-auto">
                  阅读全文
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </section>
    </div>
  )
}

function ArtistCard({ artist }) {
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <div className="relative">
        <Image
          src={artist.image || "/placeholder.svg"}
          alt={artist.name}
          width={400}
          height={400}
          className="w-full h-64 object-cover"
        />
        <div className="absolute top-2 left-2">
          <Badge variant="secondary" className="bg-black/70 hover:bg-black/70 text-white">
            {artist.category}
          </Badge>
        </div>
      </div>
      <CardHeader className="p-4 pb-2">
        <CardTitle className="text-lg">{artist.name}</CardTitle>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <p className="text-sm text-gray-600 mb-2">{artist.specialty}</p>
        <p className="text-sm text-gray-600 line-clamp-2">{artist.bio}</p>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Button size="sm" className="ml-auto">
          查看详情
        </Button>
      </CardFooter>
    </Card>
  )
}

// Sample data
const artists = [
  {
    id: "1",
    name: "陈志远",
    specialty: "当代水墨",
    bio: "陈志远是中国当代水墨画领域的代表人物，作品融合传统与现代元素，在国内外多家美术馆展出。",
    image: "/placeholder.svg?height=400&width=400",
    category: "绘画",
  },
  {
    id: "2",
    name: "林小雨",
    specialty: "油画风景",
    bio: "林小雨专注于油画风景创作，以独特的色彩感和光影处理著称，作品多次获得国家级奖项。",
    image: "/placeholder.svg?height=400&width=400",
    category: "绘画",
  },
  {
    id: "3",
    name: "赵明",
    specialty: "雕塑艺术",
    bio: "赵明是中国当代雕塑艺术家，作品结合东方哲学思想和现代雕塑语言，探索人与自然的关系。",
    image: "/placeholder.svg?height=400&width=400",
    category: "雕塑",
  },
  {
    id: "4",
    name: "王丹",
    specialty: "水彩插画",
    bio: "王丹以细腻的水彩插画作品闻名，擅长捕捉日常生活中的温暖瞬间，出版多部插画集。",
    image: "/placeholder.svg?height=400&width=400",
    category: "绘画",
  },
  {
    id: "5",
    name: "张伟",
    specialty: "当代摄影",
    bio: "张伟是中国当代摄影艺术家，作品关注城市变迁和人文景观，曾在国内外多家摄影展获奖。",
    image: "/placeholder.svg?height=400&width=400",
    category: "摄影",
  },
  {
    id: "6",
    name: "李强",
    specialty: "数字艺术",
    bio: "李强是新锐数字艺术家，擅长运用新媒体技术创作沉浸式艺术作品，作品多次在国际数字艺术节展出。",
    image: "/placeholder.svg?height=400&width=400",
    category: "数字艺术",
  },
  {
    id: "7",
    name: "刘芳",
    specialty: "陶艺创作",
    bio: "刘芳专注于陶艺创作二十余年，作品融合传统陶艺技法与现代设计理念，在国内外享有盛誉。",
    image: "/placeholder.svg?height=400&width=400",
    category: "雕塑",
  },
  {
    id: "8",
    name: "周明",
    specialty: "版画艺术",
    bio: "周明是中国当代版画艺术家，作品题材广泛，技法精湛，多次获得全国版画展金奖。",
    image: "/placeholder.svg?height=400&width=400",
    category: "绘画",
  },
]

const artStyles = [
  { name: "写实主义", count: 24, slug: "realism" },
  { name: "印象派", count: 18, slug: "impressionism" },
  { name: "抽象艺术", count: 15, slug: "abstract" },
  { name: "极简主义", count: 12, slug: "minimalism" },
  { name: "超现实主义", count: 10, slug: "surrealism" },
  { name: "波普艺术", count: 8, slug: "pop-art" },
]

const interviews = [
  {
    title: "对话陈志远：传统水墨的当代表达",
    description: "著名水墨画家陈志远分享他对传统水墨画在当代语境下的创新理解和实践经验。",
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    title: "林小雨谈风景油画创作",
    description: "油画家林小雨分享她的创作灵感来源、色彩运用技巧以及对自然风景的独特理解。",
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    title: "数字时代的艺术创新：李强访谈",
    description: "数字艺术家李强探讨技术与艺术的融合，以及数字媒介如何拓展艺术表达的可能性。",
    image: "/placeholder.svg?height=400&width=600",
  },
]

