import Link from "next/link"
import Image from "next/image"
import { Filter, Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"

export default function CoursesPage() {
  return (
    <div className="container mx-auto py-12 px-4 md:px-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl md:text-4xl font-bold mb-2 text-gray-800">格学馆</h1>
          <p className="text-gray-500">探索由专业艺术家和教育者提供的高质量艺术课程</p>
        </div>
        <div className="flex items-center gap-2 w-full md:w-auto">
          <div className="relative w-full md:w-auto">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
            <Input type="search" placeholder="搜索课程..." className="pl-8 w-full md:w-[250px]" />
          </div>
          <Button variant="outline" size="icon" className="border-pastel-purple text-pastel-purple">
            <Filter className="h-4 w-4" />
            <span className="sr-only">筛选</span>
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" className="mb-8">
        <TabsList className="mb-6 bg-transparent p-0 h-auto space-x-2 flex overflow-x-auto no-scrollbar justify-start md:justify-center">
          <TabsTrigger
            value="all"
            className="data-[state=active]:bg-pastel-purple data-[state=active]:text-white rounded-full px-6 py-2"
          >
            全部课程
          </TabsTrigger>
          <TabsTrigger
            value="beginner"
            className="data-[state=active]:bg-pastel-blue data-[state=active]:text-white rounded-full px-6 py-2"
          >
            入门课程
          </TabsTrigger>
          <TabsTrigger
            value="intermediate"
            className="data-[state=active]:bg-pastel-pink data-[state=active]:text-white rounded-full px-6 py-2"
          >
            进阶课程
          </TabsTrigger>
          <TabsTrigger
            value="advanced"
            className="data-[state=active]:bg-pastel-mint data-[state=active]:text-white rounded-full px-6 py-2"
          >
            高级课程
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {courses.map((course) => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="beginner">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {courses
              .filter((course) => course.level === "入门")
              .map((course) => (
                <CourseCard key={course.id} course={course} />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="intermediate">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {courses
              .filter((course) => course.level === "进阶")
              .map((course) => (
                <CourseCard key={course.id} course={course} />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="advanced">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {courses
              .filter((course) => course.level === "高级")
              .map((course) => (
                <CourseCard key={course.id} course={course} />
              ))}
          </div>
        </TabsContent>
      </Tabs>

      <Separator className="my-12" />

      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-6 text-gray-800">热门课程分类</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((category, index) => (
            <Link key={index} href={`/courses/category/${category.slug}`} className="group">
              <div className="bg-white rounded-lg p-6 text-center transition-all hover:shadow-md border border-gray-100">
                <div className="text-3xl mb-2">{category.icon}</div>
                <h3 className="font-medium text-gray-800 group-hover:text-pastel-purple transition-colors">
                  {category.name}
                </h3>
                <p className="text-sm text-gray-500">{category.count}个课程</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-bold mb-6 text-gray-800">为什么选择格物艺术空间的课程？</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-pastel-purple/10 p-6 rounded-2xl">
            <div className="text-4xl mb-4">👨‍🏫</div>
            <h3 className="text-xl font-semibold mb-2 text-gray-800">专业艺术教师</h3>
            <p className="text-gray-600">我们的课程由经验丰富的艺术家和教育者精心设计和授课，确保高质量的学习体验。</p>
          </div>
          <div className="bg-pastel-blue/10 p-6 rounded-2xl">
            <div className="text-4xl mb-4">🎯</div>
            <h3 className="text-xl font-semibold mb-2 text-gray-800">系统化学习</h3>
            <p className="text-gray-600">从基础到高级，我们提供系统化的课程体系，帮助您循序渐进地提升艺术技能。</p>
          </div>
          <div className="bg-pastel-pink/10 p-6 rounded-2xl">
            <div className="text-4xl mb-4">💬</div>
            <h3 className="text-xl font-semibold mb-2 text-gray-800">互动反馈</h3>
            <p className="text-gray-600">通过在线互动和作业点评，获得专业教师的个性化指导和建议。</p>
          </div>
        </div>
      </section>
    </div>
  )
}

function CourseCard({ course }) {
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow h-full group">
      <div className="relative">
        <Image
          src={course.image || "/placeholder.svg"}
          alt={course.title}
          width={400}
          height={225}
          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-2 left-2 flex gap-2">
          <Badge
            className={`
            ${course.category === "水彩" ? "bg-pastel-blue" : ""}
            ${course.category === "素描" ? "bg-gray-700" : ""}
            ${course.category === "国画" ? "bg-pastel-mint" : ""}
            ${course.category === "油画" ? "bg-pastel-pink" : ""}
            ${course.category === "插画" ? "bg-pastel-purple" : ""}
            ${course.category === "陶艺" ? "bg-pastel-yellow" : ""}
            ${course.category === "版画" ? "bg-gray-500" : ""}
            text-white rounded-full px-3 py-1
          `}
          >
            {course.category}
          </Badge>
          {course.isNew && <Badge className="bg-pastel-pink text-white rounded-full px-3 py-1">新课</Badge>}
        </div>
      </div>
      <CardHeader className="p-4 pb-2">
        <CardTitle className="text-lg text-gray-800 group-hover:text-pastel-purple transition-colors">
          {course.title}
        </CardTitle>
        <CardDescription className="flex items-center">
          <span>{course.instructor}</span>
          <span className="mx-2">•</span>
          <span>{course.level}</span>
        </CardDescription>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <p className="text-sm text-gray-600 line-clamp-2">{course.description}</p>
        <div className="mt-2 flex items-center text-sm">
          <span className="text-yellow-500">★★★★★</span>
          <span className="ml-1">{course.rating}</span>
          <span className="mx-1">|</span>
          <span>{course.students}名学生</span>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex justify-between items-center">
        <span className="font-bold text-lg text-pastel-purple">¥{course.price}</span>
        <Button className="bg-pastel-purple/10 text-pastel-purple hover:bg-pastel-purple/20 rounded-full">
          查看详情
        </Button>
      </CardFooter>
    </Card>
  )
}

// Sample data
const courses = [
  {
    id: "1",
    title: "水彩风景入门",
    instructor: "李明",
    level: "入门",
    description: "学习水彩绘画的基本技法，掌握风景画的构图和色彩运用，适合零基础学习者。",
    price: "299",
    image: "/placeholder.svg?height=400&width=600",
    category: "水彩",
    rating: "4.8",
    students: "1,245",
    isNew: true,
  },
  {
    id: "2",
    title: "人物素描技法",
    instructor: "张华",
    level: "进阶",
    description: "深入学习人物素描的比例、结构和明暗关系，提升人物刻画能力。",
    price: "399",
    image: "/placeholder.svg?height=400&width=600",
    category: "素描",
    rating: "4.9",
    students: "987",
    isNew: false,
  },
  {
    id: "3",
    title: "中国山水画基础",
    instructor: "王芳",
    level: "入门",
    description: "了解中国传统山水画的历史与技法，学习基本笔法和构图原则。",
    price: "499",
    image: "/placeholder.svg?height=400&width=600",
    category: "国画",
    rating: "4.7",
    students: "756",
    isNew: false,
  },
  {
    id: "4",
    title: "油画创作进阶",
    instructor: "刘强",
    level: "高级",
    description: "探索油画创作的高级技巧，学习大师作品分析和个人风格的建立。",
    price: "599",
    image: "/placeholder.svg?height=400&width=600",
    category: "油画",
    rating: "4.9",
    students: "543",
    isNew: true,
  },
  {
    id: "5",
    title: "插画设计基础",
    instructor: "赵小明",
    level: "入门",
    description: "学习插画设计的基本原理和技巧，掌握数字绘画工具的使用方法。",
    price: "349",
    image: "/placeholder.svg?height=400&width=600",
    category: "插画",
    rating: "4.6",
    students: "1,876",
    isNew: false,
  },
  {
    id: "6",
    title: "陶艺创作入门",
    instructor: "林小雨",
    level: "入门",
    description: "了解陶艺的基本工具和材料，学习手捏、拉坯等基础成型技法。",
    price: "449",
    image: "/placeholder.svg?height=400&width=600",
    category: "陶艺",
    rating: "4.8",
    students: "432",
    isNew: true,
  },
  {
    id: "7",
    title: "版画技法详解",
    instructor: "陈志远",
    level: "进阶",
    description: "深入学习木刻、铜版、丝网等多种版画技法，提升创作能力。",
    price: "399",
    image: "/placeholder.svg?height=400&width=600",
    category: "版画",
    rating: "4.7",
    students: "321",
    isNew: false,
  },
  {
    id: "8",
    title: "水墨人物画进阶",
    instructor: "王丹",
    level: "进阶",
    description: "学习传统水墨人物画的技法与表现，提升人物刻画的艺术性。",
    price: "499",
    image: "/placeholder.svg?height=400&width=600",
    category: "国画",
    rating: "4.9",
    students: "654",
    isNew: false,
  },
]

const categories = [
  { name: "油画", icon: "🎨", count: 24, slug: "oil-painting" },
  { name: "水彩", icon: "💦", count: 18, slug: "watercolor" },
  { name: "素描", icon: "✏️", count: 15, slug: "sketch" },
  { name: "国画", icon: "🖌️", count: 20, slug: "chinese-painting" },
  { name: "插画", icon: "📚", count: 12, slug: "illustration" },
  { name: "雕塑", icon: "🗿", count: 8, slug: "sculpture" },
]

