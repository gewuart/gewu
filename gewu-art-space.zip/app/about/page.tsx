import Image from "next/image"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"

export default function AboutPage() {
  return (
    <div className="container mx-auto py-8 px-4 md:px-6">
      <div className="max-w-3xl mx-auto mb-12">
        <h1 className="text-3xl font-bold mb-4 text-center">关于格物艺术空间</h1>
        <p className="text-lg text-center text-gray-600 mb-8">探索艺术的无限可能，发现创作的独特魅力</p>

        <div className="relative w-full h-[300px] rounded-lg overflow-hidden mb-8">
          <Image src="/placeholder.svg?height=600&width=1200" alt="格物艺术空间" fill className="object-cover" />
        </div>

        <div className="prose prose-lg max-w-none">
          <p>
            格物艺术空间成立于2018年，是一家致力于艺术教育、创作支持和艺术推广的综合性平台。我们的名字源自中国古代"格物致知"的哲学思想，寓意通过对艺术的深入探索和实践，获得对美的真知灼见。
          </p>

          <p>
            作为一个连接艺术创作者、学习者和爱好者的桥梁，格物艺术空间提供全方位的艺术服务，包括专业在线课程、丰富的绘画素材库、优质画材商城、最新画展资讯以及艺术家推广平台。
          </p>

          <p>
            我们的使命是让艺术变得更加亲近和普及，帮助每一位艺术爱好者找到自己的创作道路，同时为专业艺术家提供展示和交流的平台。无论您是初学者还是资深创作者，格物艺术空间都将是您艺术旅程中的忠实伙伴。
          </p>
        </div>
      </div>

      <Separator className="my-12" />

      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-8 text-center">我们的核心价值</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <Card>
            <CardContent className="p-6">
              <div className="text-4xl mb-4 text-center">🎨</div>
              <h3 className="text-xl font-semibold mb-2 text-center">专业品质</h3>
              <p className="text-gray-600 text-center">
                我们坚持提供最专业的艺术教育和最优质的艺术资源，确保每位用户获得卓越的体验。
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="text-4xl mb-4 text-center">🌱</div>
              <h3 className="text-xl font-semibold mb-2 text-center">创新成长</h3>
              <p className="text-gray-600 text-center">
                我们鼓励创新思维和持续学习，帮助每位艺术爱好者在创作道路上不断突破和成长。
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="text-4xl mb-4 text-center">🤝</div>
              <h3 className="text-xl font-semibold mb-2 text-center">艺术共享</h3>
              <p className="text-gray-600 text-center">
                我们致力于建立一个开放、包容的艺术社区，促进艺术家之间的交流与合作。
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-8 text-center">我们的团队</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {teamMembers.map((member, index) => (
            <div key={index} className="text-center">
              <div className="relative w-40 h-40 mx-auto rounded-full overflow-hidden mb-4">
                <Image src={member.image || "/placeholder.svg"} alt={member.name} fill className="object-cover" />
              </div>
              <h3 className="font-semibold text-lg">{member.name}</h3>
              <p className="text-gray-500">{member.role}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mb-12 bg-gray-50 p-8 rounded-lg">
        <h2 className="text-2xl font-bold mb-6 text-center">我们的成就</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          <div>
            <div className="text-3xl font-bold mb-2">5000+</div>
            <p className="text-gray-600">注册学员</p>
          </div>
          <div>
            <div className="text-3xl font-bold mb-2">200+</div>
            <p className="text-gray-600">专业课程</p>
          </div>
          <div>
            <div className="text-3xl font-bold mb-2">50+</div>
            <p className="text-gray-600">合作艺术家</p>
          </div>
          <div>
            <div className="text-3xl font-bold mb-2">20+</div>
            <p className="text-gray-600">城市覆盖</p>
          </div>
        </div>
      </section>

      <section className="text-center mb-12">
        <h2 className="text-2xl font-bold mb-4">加入我们</h2>
        <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
          无论您是想学习艺术、分享创作还是寻找合作机会，格物艺术空间都欢迎您的加入。
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <Button asChild size="lg">
            <Link href="/courses">探索课程</Link>
          </Button>
          <Button asChild variant="outline" size="lg">
            <Link href="/contact">联系我们</Link>
          </Button>
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-bold mb-6 text-center">合作伙伴</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {partners.map((partner, index) => (
            <div
              key={index}
              className="bg-white p-4 rounded-lg border border-gray-200 flex items-center justify-center h-24"
            >
              <Image
                src={partner.logo || "/placeholder.svg"}
                alt={partner.name}
                width={120}
                height={60}
                className="max-h-12 w-auto object-contain"
              />
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}

// Sample data
const teamMembers = [
  {
    name: "张艺",
    role: "创始人 & 艺术总监",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    name: "李明",
    role: "教育总监",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    name: "王芳",
    role: "内容策划",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    name: "赵强",
    role: "技术总监",
    image: "/placeholder.svg?height=200&width=200",
  },
]

const partners = [
  { name: "中央美术学院", logo: "/placeholder.svg?height=60&width=120" },
  { name: "中国美术家协会", logo: "/placeholder.svg?height=60&width=120" },
  { name: "国家博物馆", logo: "/placeholder.svg?height=60&width=120" },
  { name: "温莎牛顿", logo: "/placeholder.svg?height=60&width=120" },
  { name: "马利", logo: "/placeholder.svg?height=60&width=120" },
  { name: "樱花", logo: "/placeholder.svg?height=60&width=120" },
]

