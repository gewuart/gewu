import Link from "next/link"
import Image from "next/image"
import { Download, Filter, Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"

export default function ResourcesPage() {
  return (
    <div className="container mx-auto py-8 px-4 md:px-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">绘画素材库</h1>
          <p className="text-gray-500">丰富的参考素材，助力您的艺术创作</p>
        </div>
        <div className="flex items-center gap-2 w-full md:w-auto">
          <div className="relative w-full md:w-auto">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
            <Input type="search" placeholder="搜索素材..." className="pl-8 w-full md:w-[250px]" />
          </div>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
            <span className="sr-only">筛选</span>
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" className="mb-8">
        <TabsList className="mb-4">
          <TabsTrigger value="all">全部素材</TabsTrigger>
          <TabsTrigger value="reference">参考图</TabsTrigger>
          <TabsTrigger value="texture">纹理贴图</TabsTrigger>
          <TabsTrigger value="model">人体模型</TabsTrigger>
          <TabsTrigger value="template">模板</TabsTrigger>
        </TabsList>
        <TabsContent value="all">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {resources.map((resource) => (
              <ResourceCard key={resource.id} resource={resource} />
            ))}
          </div>
        </TabsContent>
        <TabsContent value="reference">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {resources
              .filter((resource) => resource.type === "参考图")
              .map((resource) => (
                <ResourceCard key={resource.id} resource={resource} />
              ))}
          </div>
        </TabsContent>
        <TabsContent value="texture">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {resources
              .filter((resource) => resource.type === "纹理贴图")
              .map((resource) => (
                <ResourceCard key={resource.id} resource={resource} />
              ))}
          </div>
        </TabsContent>
        <TabsContent value="model">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {resources
              .filter((resource) => resource.type === "人体模型")
              .map((resource) => (
                <ResourceCard key={resource.id} resource={resource} />
              ))}
          </div>
        </TabsContent>
        <TabsContent value="template">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {resources
              .filter((resource) => resource.type === "模板")
              .map((resource) => (
                <ResourceCard key={resource.id} resource={resource} />
              ))}
          </div>
        </TabsContent>
      </Tabs>

      <Separator className="my-8" />

      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-4">素材分类</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {resourceCategories.map((category, index) => (
            <Link key={index} href={`/resources/category/${category.slug}`} className="group">
              <div className="bg-gray-50 rounded-lg p-4 text-center transition-all hover:bg-gray-100 hover:shadow-sm">
                <div className="text-3xl mb-2">{category.icon}</div>
                <h3 className="font-medium">{category.name}</h3>
                <p className="text-sm text-gray-500">{category.count}个素材</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-bold mb-6">会员特权</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-gray-50 p-6 rounded-lg">
            <div className="text-4xl mb-4">⬇️</div>
            <h3 className="text-xl font-semibold mb-2">无限下载</h3>
            <p className="text-gray-600">会员可无限制下载所有素材，满足您的创作需求。</p>
          </div>
          <div className="bg-gray-50 p-6 rounded-lg">
            <div className="text-4xl mb-4">🔍</div>
            <h3 className="text-xl font-semibold mb-2">高清素材</h3>
            <p className="text-gray-600">提供高分辨率素材，确保您的作品细节丰富。</p>
          </div>
          <div className="bg-gray-50 p-6 rounded-lg">
            <div className="text-4xl mb-4">🆕</div>
            <h3 className="text-xl font-semibold mb-2">优先更新</h3>
            <p className="text-gray-600">会员可优先获取最新上传的素材资源。</p>
          </div>
        </div>
        <div className="mt-8 text-center">
          <Button size="lg" className="px-8">
            成为会员
          </Button>
        </div>
      </section>
    </div>
  )
}

function ResourceCard({ resource }) {
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <div className="relative">
        <Image
          src={resource.image || "/placeholder.svg"}
          alt={resource.title}
          width={400}
          height={400}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-2 left-2">
          <Badge variant="secondary" className="bg-black/70 hover:bg-black/70 text-white">
            {resource.type}
          </Badge>
        </div>
        {resource.isPremium && (
          <div className="absolute top-2 right-2">
            <Badge className="bg-amber-500 hover:bg-amber-600">会员专享</Badge>
          </div>
        )}
      </div>
      <CardHeader className="p-4 pb-2">
        <CardTitle className="text-lg">{resource.title}</CardTitle>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <p className="text-sm text-gray-600 line-clamp-2">{resource.description}</p>
        <div className="mt-2 flex items-center text-sm">
          <span className="text-gray-500">分辨率: {resource.resolution}</span>
          <span className="mx-1">•</span>
          <span className="text-gray-500">{resource.format}</span>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex justify-between items-center">
        <span className="text-sm text-gray-500">下载次数: {resource.downloads}</span>
        <Button size="sm" variant={resource.isPremium ? "default" : "outline"}>
          <Download className="h-4 w-4 mr-2" />
          下载
        </Button>
      </CardFooter>
    </Card>
  )
}

// Sample data
const resources = [
  {
    id: "1",
    title: "人物姿势参考集",
    description: "包含100张不同角度和动作的人物姿势参考图，适合人物绘画练习。",
    image: "/placeholder.svg?height=400&width=400",
    type: "参考图",
    resolution: "4000x3000",
    format: "JPG",
    downloads: "2,345",
    isPremium: true,
  },
  {
    id: "2",
    title: "自然纹理合集",
    description: "高清自然纹理图集，包括木纹、石纹、水纹等多种自然材质纹理。",
    image: "/placeholder.svg?height=400&width=400",
    type: "纹理贴图",
    resolution: "5000x5000",
    format: "PNG",
    downloads: "1,876",
    isPremium: false,
  },
  {
    id: "3",
    title: "3D人体模型素材",
    description: "高精度3D人体模型，包含多个角度视图，适合人体结构学习。",
    image: "/placeholder.svg?height=400&width=400",
    type: "人体模型",
    resolution: "6000x4000",
    format: "PNG/OBJ",
    downloads: "1,543",
    isPremium: true,
  },
  {
    id: "4",
    title: "水彩画背景模板",
    description: "20种高质量水彩画背景模板，适合水彩创作和混合媒介作品。",
    image: "/placeholder.svg?height=400&width=400",
    type: "模板",
    resolution: "4500x3000",
    format: "PSD/JPG",
    downloads: "987",
    isPremium: false,
  },
  {
    id: "5",
    title: "动物解剖参考",
    description: "常见动物的解剖结构参考图集，包括骨骼和肌肉系统。",
    image: "/placeholder.svg?height=400&width=400",
    type: "参考图",
    resolution: "5000x3500",
    format: "PDF/JPG",
    downloads: "1,234",
    isPremium: true,
  },
  {
    id: "6",
    title: "城市建筑参考",
    description: "世界各地城市建筑风格参考图集，适合场景设计和建筑绘画。",
    image: "/placeholder.svg?height=400&width=400",
    type: "参考图",
    resolution: "4800x3200",
    format: "JPG",
    downloads: "876",
    isPremium: false,
  },
  {
    id: "7",
    title: "金属材质纹理",
    description: "各种金属材质的高清纹理图集，包括金、银、铜、铁等材质。",
    image: "/placeholder.svg?height=400&width=400",
    type: "纹理贴图",
    resolution: "6000x6000",
    format: "PNG",
    downloads: "1,432",
    isPremium: true,
  },
  {
    id: "8",
    title: "插画配色方案",
    description: "100种精选插画配色方案，帮助您快速找到合适的色彩组合。",
    image: "/placeholder.svg?height=400&width=400",
    type: "模板",
    resolution: "3000x2000",
    format: "AI/PDF",
    downloads: "2,156",
    isPremium: false,
  },
]

const resourceCategories = [
  { name: "人物", icon: "👤", count: 156, slug: "people" },
  { name: "风景", icon: "🏞️", count: 124, slug: "landscape" },
  { name: "动物", icon: "🐾", count: 98, slug: "animals" },
  { name: "纹理", icon: "🧩", count: 87, slug: "texture" },
  { name: "模板", icon: "📝", count: 65, slug: "template" },
  { name: "3D模型", icon: "🧊", count: 42, slug: "3d-model" },
]

