import Link from "next/link"
import Image from "next/image"
import { ChevronRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function Home() {
  return (
    <div className="flex flex-col">
      {/* Hero Section - Responsive Split Design */}
      <section className="bg-gradient-to-r from-pastel-pink to-pastel-purple py-12 md:py-20 px-4 md:px-8 lg:px-16">
        <div className="container mx-auto">
          <div className="flex flex-col lg:flex-row items-center gap-8 lg:gap-16">
            <div className="w-full lg:w-1/2 text-center lg:text-left">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-white leading-tight">
                探索艺术
                <br />
                发现美的世界
              </h1>
              <p className="text-lg md:text-xl text-white/80 mb-8 max-w-lg mx-auto lg:mx-0">
                格物艺术空间，连接艺术与生活的桥梁，为您带来独特的艺术体验
              </p>
              <div className="flex flex-wrap gap-4 justify-center lg:justify-start">
                <Button className="bg-white text-pastel-purple hover:bg-white/90 rounded-full px-8 py-6 text-lg">
                  探索课程
                </Button>
                <Button
                  variant="outline"
                  className="text-white border-white hover:bg-white/20 rounded-full px-8 py-6 text-lg"
                >
                  了解更多
                </Button>
              </div>
            </div>
            <div className="w-full lg:w-1/2 mt-8 lg:mt-0">
              <div className="relative aspect-square max-w-md mx-auto">
                <div className="absolute inset-0 bg-pastel-mint rounded-3xl rotate-6"></div>
                <div className="absolute inset-0 bg-pastel-yellow rounded-3xl -rotate-3"></div>
                <div className="absolute inset-0 overflow-hidden rounded-3xl">
                  <Image
                    src="/placeholder.svg?height=600&width=600"
                    alt="艺术作品"
                    fill
                    priority
                    className="object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Category Navigation - Responsive Tabs */}
      <section className="py-8 px-4 md:px-8 bg-white">
        <div className="container mx-auto">
          <div className="flex overflow-x-auto md:flex-wrap md:justify-center gap-3 pb-2 no-scrollbar">
            <Button className="bg-pastel-purple text-white hover:bg-pastel-purple/90 rounded-full px-6 whitespace-nowrap">
              全部
            </Button>
            <Button
              variant="outline"
              className="border-pastel-blue text-pastel-blue hover:bg-pastel-blue/10 rounded-full px-6 whitespace-nowrap"
            >
              课程
            </Button>
            <Button
              variant="outline"
              className="border-pastel-pink text-pastel-pink hover:bg-pastel-pink/10 rounded-full px-6 whitespace-nowrap"
            >
              画材
            </Button>
            <Button
              variant="outline"
              className="border-pastel-mint text-pastel-mint hover:bg-pastel-mint/10 rounded-full px-6 whitespace-nowrap"
            >
              展览
            </Button>
            <Button
              variant="outline"
              className="border-pastel-yellow text-pastel-yellow hover:bg-pastel-yellow/10 rounded-full px-6 whitespace-nowrap"
            >
              艺术家
            </Button>
          </div>
        </div>
      </section>

      {/* Featured Courses - Responsive Grid/Carousel */}
      <section className="py-12 px-4 md:px-8 bg-pastel-blue/10">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-8">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4 md:mb-0">精选课程</h2>
            <Link href="/courses" className="text-pastel-purple flex items-center group">
              查看全部 <ChevronRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>

          {/* Mobile: Horizontal Scroll, Desktop: Grid */}
          <div className="flex overflow-x-auto gap-6 pb-6 md:grid md:grid-cols-2 lg:grid-cols-4 md:gap-6 -mx-4 px-4 md:mx-0 md:px-0 no-scrollbar snap-x snap-mandatory md:snap-none">
            {featuredCourses.map((course, index) => (
              <div key={index} className="min-w-[280px] md:min-w-0 flex-shrink-0 snap-start md:snap-align-none group">
                <div className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-lg transition-shadow">
                  <div className="relative aspect-[4/3] overflow-hidden">
                    <Image
                      src={course.image || "/placeholder.svg"}
                      alt={course.title}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-3 left-3">
                      <Badge
                        className={`
                        ${course.category === "水彩" ? "bg-pastel-blue text-white" : ""}
                        ${course.category === "素描" ? "bg-pastel-purple text-white" : ""}
                        ${course.category === "国画" ? "bg-pastel-mint text-white" : ""}
                        ${course.category === "油画" ? "bg-pastel-pink text-white" : ""}
                        rounded-full px-3 py-1
                      `}
                      >
                        {course.category}
                      </Badge>
                    </div>
                  </div>
                  <div className="p-5">
                    <h3 className="font-bold text-xl mb-2 text-gray-800">{course.title}</h3>
                    <p className="text-gray-600 mb-3">{course.instructor}</p>
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-xl text-pastel-purple">¥{course.price}</span>
                      <Button className="bg-pastel-purple/10 text-pastel-purple hover:bg-pastel-purple/20 rounded-full">
                        查看详情
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Latest News - Responsive Tabs and Cards */}
      <section className="py-12 px-4 md:px-8 bg-white">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-8">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4 md:mb-0">最新动态</h2>
            <Link href="/news" className="text-pastel-purple flex items-center group">
              查看全部 <ChevronRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>

          <Tabs defaultValue="all">
            <TabsList className="w-full mb-8 bg-transparent p-0 h-auto space-x-2 flex overflow-x-auto no-scrollbar justify-start md:justify-center">
              <TabsTrigger
                value="all"
                className="data-[state=active]:bg-pastel-purple data-[state=active]:text-white rounded-full px-6 py-2"
              >
                全部
              </TabsTrigger>
              <TabsTrigger
                value="courses"
                className="data-[state=active]:bg-pastel-blue data-[state=active]:text-white rounded-full px-6 py-2"
              >
                课程
              </TabsTrigger>
              <TabsTrigger
                value="supplies"
                className="data-[state=active]:bg-pastel-pink data-[state=active]:text-white rounded-full px-6 py-2"
              >
                画材
              </TabsTrigger>
              <TabsTrigger
                value="exhibitions"
                className="data-[state=active]:bg-pastel-mint data-[state=active]:text-white rounded-full px-6 py-2"
              >
                展讯
              </TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {latestNews.slice(0, 6).map((news, index) => (
                  <NewsCard key={index} news={news} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="courses" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {latestNews
                  .filter((news) => news.category === "课程")
                  .map((news, index) => (
                    <NewsCard key={index} news={news} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="supplies" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {latestNews
                  .filter((news) => news.category === "画材")
                  .map((news, index) => (
                    <NewsCard key={index} news={news} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="exhibitions" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {latestNews
                  .filter((news) => news.category === "展讯")
                  .map((news, index) => (
                    <NewsCard key={index} news={news} />
                  ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Art Supplies - Responsive Grid with Featured Item */}
      <section className="py-12 px-4 md:px-8 bg-pastel-pink/10">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-8">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4 md:mb-0">画材精选</h2>
            <Link href="/shop" className="text-pastel-pink flex items-center group">
              前往商城 <ChevronRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Featured Supply */}
            <div className="bg-white rounded-2xl overflow-hidden shadow-lg p-6">
              <div className="flex flex-col md:flex-row gap-6">
                <div className="relative aspect-square w-full md:w-1/2 rounded-xl overflow-hidden">
                  <Image
                    src={newSupplies[0].image || "/placeholder.svg"}
                    alt={newSupplies[0].title}
                    fill
                    className="object-contain p-4"
                  />
                  <div className="absolute top-3 right-3">
                    <Badge className="bg-pastel-pink text-white rounded-full px-3 py-1">
                      -{newSupplies[0].discount}%
                    </Badge>
                  </div>
                </div>
                <div className="w-full md:w-1/2 flex flex-col justify-center">
                  <h3 className="font-bold text-2xl mb-2 text-gray-800">{newSupplies[0].title}</h3>
                  <p className="text-gray-600 mb-4">{newSupplies[0].brand}</p>
                  <p className="text-gray-600 mb-6">{newSupplies[0].description}</p>
                  <div className="flex items-center gap-3 mb-6">
                    <span className="font-bold text-2xl text-pastel-pink">¥{newSupplies[0].discountPrice}</span>
                    <span className="text-gray-400 line-through text-lg">¥{newSupplies[0].originalPrice}</span>
                  </div>
                  <Button className="bg-pastel-pink text-white hover:bg-pastel-pink/90 rounded-full w-full md:w-auto">
                    加入购物车
                  </Button>
                </div>
              </div>
            </div>

            {/* Other Supplies Grid */}
            <div className="grid grid-cols-2 gap-4">
              {newSupplies.slice(1).map((supply, index) => (
                <div
                  key={index}
                  className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow p-4 group"
                >
                  <div className="relative aspect-square rounded-lg overflow-hidden mb-3">
                    <Image
                      src={supply.image || "/placeholder.svg"}
                      alt={supply.title}
                      fill
                      className="object-contain p-4 group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-2 right-2">
                      <Badge className="bg-pastel-pink text-white rounded-full px-2 py-0.5 text-xs">
                        -{supply.discount}%
                      </Badge>
                    </div>
                  </div>
                  <h3 className="font-bold text-sm md:text-base mb-1 line-clamp-1">{supply.title}</h3>
                  <p className="text-gray-500 text-xs mb-2">{supply.brand}</p>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-pastel-pink">¥{supply.discountPrice}</span>
                    <span className="text-gray-400 line-through text-xs">¥{supply.originalPrice}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Exhibitions - Responsive Cards */}
      <section className="py-12 px-4 md:px-8 bg-pastel-mint/10">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-8">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4 md:mb-0">展览资讯</h2>
            <Link href="/exhibitions" className="text-pastel-mint flex items-center group">
              查看全部 <ChevronRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {exhibitions.map((exhibition, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-lg transition-shadow group"
              >
                <div className="relative aspect-[16/9] overflow-hidden">
                  <Image
                    src={exhibition.image || "/placeholder.svg"}
                    alt={exhibition.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </div>
                <div className="p-6">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge
                      className={`
                      ${exhibition.status === "upcoming" ? "bg-pastel-blue" : "bg-pastel-mint"} 
                      text-white rounded-full px-3 py-1
                    `}
                    >
                      {exhibition.status === "upcoming" ? "即将开展" : "正在展出"}
                    </Badge>
                    <span className="text-gray-500 text-sm">{exhibition.date.split(" - ")[0]}</span>
                  </div>
                  <h3 className="font-bold text-xl mb-2 text-gray-800 group-hover:text-pastel-mint transition-colors">
                    {exhibition.title}
                  </h3>
                  <p className="text-gray-500 mb-3">{exhibition.location}</p>
                  <p className="text-gray-600 line-clamp-2 mb-4">{exhibition.description}</p>
                  <Button className="bg-pastel-mint/10 text-pastel-mint hover:bg-pastel-mint/20 rounded-full">
                    查看详情
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Artists - Responsive Grid */}
      <section className="py-12 px-4 md:px-8 bg-pastel-yellow/10">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-8">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4 md:mb-0">艺术家</h2>
            <Link href="/artists" className="text-pastel-yellow flex items-center group">
              查看全部 <ChevronRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {featuredArtists.map((artist, index) => (
              <div key={index} className="group">
                <div className="relative aspect-square rounded-full overflow-hidden mb-4 shadow-md border-4 border-white">
                  <Image
                    src={artist.image || "/placeholder.svg"}
                    alt={artist.name}
                    fill
                    className="object-cover grayscale group-hover:grayscale-0 transition-all duration-300"
                  />
                </div>
                <div className="text-center">
                  <h3 className="font-bold text-lg mb-1 text-gray-800 group-hover:text-pastel-yellow transition-colors">
                    {artist.name}
                  </h3>
                  <p className="text-gray-600">{artist.specialty}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter - Responsive Design */}
      <section className="py-16 px-4 md:px-8 bg-gradient-to-r from-pastel-purple/20 to-pastel-pink/20">
        <div className="container mx-auto max-w-4xl">
          <div className="bg-white rounded-3xl shadow-xl p-8 md:p-12">
            <div className="text-center mb-8">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">订阅艺术资讯</h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                获取最新的课程信息、展览预告和艺术活动，不错过任何艺术灵感
              </p>
            </div>
            <form className="flex flex-col md:flex-row gap-4 max-w-xl mx-auto">
              <input
                type="email"
                placeholder="您的邮箱地址"
                className="flex-1 px-6 py-4 rounded-full text-gray-900 focus:outline-none border border-gray-200 focus:border-pastel-purple"
                required
              />
              <Button
                type="submit"
                className="bg-gradient-to-r from-pastel-purple to-pastel-pink text-white hover:opacity-90 rounded-full px-8 py-4"
              >
                订阅
              </Button>
            </form>
          </div>
        </div>
      </section>
    </div>
  )
}

// Component for news cards
function NewsCard({ news }) {
  return (
    <div className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-lg transition-shadow h-full group">
      <div className="relative aspect-[16/9] overflow-hidden">
        <Image
          src={news.image || "/placeholder.svg"}
          alt={news.title}
          fill
          className="object-cover group-hover:scale-105 transition-transform duration-300"
        />
      </div>
      <div className="p-6">
        <div className="flex items-center gap-2 mb-3">
          <Badge
            className={`
            ${news.category === "课程" ? "bg-pastel-blue" : ""}
            ${news.category === "画材" ? "bg-pastel-pink" : ""}
            ${news.category === "展讯" ? "bg-pastel-mint" : ""}
            ${news.category === "艺术家" ? "bg-pastel-yellow" : ""}
            text-white rounded-full px-3 py-1
          `}
          >
            {news.category}
          </Badge>
          {news.isNew && (
            <Badge variant="outline" className="border-pastel-purple text-pastel-purple rounded-full px-3 py-1">
              新消息
            </Badge>
          )}
        </div>
        <h3 className="font-bold text-xl mb-2 text-gray-800 group-hover:text-pastel-purple transition-colors">
          {news.title}
        </h3>
        <p className="text-gray-500 text-sm mb-3">{news.date}</p>
        <p className="text-gray-600 line-clamp-3 mb-4">{news.description}</p>
        <Button className="bg-pastel-purple/10 text-pastel-purple hover:bg-pastel-purple/20 rounded-full">
          查看详情
        </Button>
      </div>
    </div>
  )
}

// Sample data
const latestNews = [
  {
    title: "水彩风景入门课程开课啦",
    date: "2023-06-15",
    description: "由著名水彩画家李明老师主讲的水彩风景入门课程将于下周开课，名额有限，请尽快报名。",
    image: "/placeholder.svg?height=400&width=600",
    category: "课程",
    isNew: true,
  },
  {
    title: "温莎牛顿水彩颜料限时8折",
    date: "2023-06-10",
    description: "英国温莎牛顿专业水彩颜料全系列限时8折优惠，活动时间6月10日至6月20日。",
    image: "/placeholder.svg?height=400&width=600",
    category: "画材",
    isNew: true,
  },
  {
    title: "当代水墨艺术展即将开幕",
    date: "2023-06-08",
    description: "《墨韵新声：当代水墨艺术展》将于6月20日在北京中央美术学院美术馆开幕，展期一个月。",
    image: "/placeholder.svg?height=400&width=600",
    category: "展讯",
    isNew: false,
  },
  {
    title: "著名油画家张华工作室开放日",
    date: "2023-06-05",
    description: "著名油画家张华将于6月25日举办工作室开放日活动，与艺术爱好者分享创作经验。",
    image: "/placeholder.svg?height=400&width=600",
    category: "艺术家",
    isNew: false,
  },
  {
    title: "儿童创意绘画课程报名开始",
    date: "2023-06-12",
    description: "暑期儿童创意绘画课程现已开放报名，培养孩子的艺术感知和创造力。",
    image: "/placeholder.svg?height=400&width=600",
    category: "课程",
    isNew: true,
  },
  {
    title: "日本樱花素描铅笔新品上市",
    date: "2023-06-07",
    description: "日本樱花素描铅笔新系列已上架，12支装，硬度从2H到8B，线条流畅。",
    image: "/placeholder.svg?height=400&width=600",
    category: "画材",
    isNew: false,
  },
]

const featuredCourses = [
  {
    title: "水彩风景入门",
    instructor: "李明",
    description: "学习水彩绘画的基本技法，掌握风景画的构图和色彩运用，适合零基础学习者。",
    price: "299",
    image: "/placeholder.svg?height=400&width=600",
    category: "水彩",
  },
  {
    title: "人物素描技法",
    instructor: "张华",
    description: "深入学习人物素描的比例、结构和明暗关系，提升人物刻画能力。",
    price: "399",
    image: "/placeholder.svg?height=400&width=600",
    category: "素描",
  },
  {
    title: "中国山水画基础",
    instructor: "王芳",
    description: "了解中国传统山水画的历史与技法，学习基本笔法和构图原则。",
    price: "499",
    image: "/placeholder.svg?height=400&width=600",
    category: "国画",
  },
  {
    title: "油画创作进阶",
    instructor: "刘强",
    description: "探索油画创作的高级技巧，学习大师作品分析和个人风格的建立。",
    price: "599",
    image: "/placeholder.svg?height=400&width=600",
    category: "油画",
  },
]

const newSupplies = [
  {
    title: "温莎牛顿专业水彩颜料24色",
    brand: "Windsor & Newton",
    originalPrice: "899",
    discountPrice: "719",
    discount: 20,
    image: "/placeholder.svg?height=400&width=400",
    description: "英国温莎牛顿专业水彩颜料，24色套装，色彩鲜艳，透明度高，适合专业水彩创作。",
  },
  {
    title: "达芬奇顶级水彩画笔套装",
    brand: "Da Vinci",
    originalPrice: "699",
    discountPrice: "559",
    discount: 20,
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    title: "阿诗水彩纸300g/㎡ 10张",
    brand: "Arches",
    originalPrice: "199",
    discountPrice: "159",
    discount: 20,
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    title: "施密特油画颜料12色套装",
    brand: "Schmincke",
    originalPrice: "1299",
    discountPrice: "1039",
    discount: 20,
    image: "/placeholder.svg?height=400&width=400",
  },
]

const exhibitions = [
  {
    title: "墨韵新声：当代水墨艺术展",
    location: "北京 · 中央美术学院美术馆",
    date: "2023年6月20日 - 2023年7月20日",
    description: "展览汇集30位当代艺术家的水墨作品，探索传统水墨在当代语境下的创新表达。",
    image: "/placeholder.svg?height=400&width=600",
    status: "upcoming",
  },
  {
    title: "色彩的交响：现代油画艺术展",
    location: "上海 · 当代艺术博物馆",
    date: "2023年5月20日 - 2023年8月20日",
    description: "展出来自国内外20位艺术家的油画作品，探索色彩在现代油画中的表现力和情感传达。",
    image: "/placeholder.svg?height=400&width=600",
    status: "ongoing",
  },
]

const featuredArtists = [
  {
    name: "陈志远",
    specialty: "当代水墨",
    bio: "陈志远是中国当代水墨画领域的代表人物，作品融合传统与现代元素，在国内外多家美术馆展出。",
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    name: "林小雨",
    specialty: "油画风景",
    bio: "林小雨专注于油画风景创作，以独特的色彩感和光影处理著称，作品多次获得国家级奖项。",
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    name: "赵明",
    specialty: "雕塑艺术",
    bio: "赵明是中国当代雕塑艺术家，作品结合东方哲学思想和现代雕塑语言，探索人与自然的关系。",
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    name: "王丹",
    specialty: "水彩插画",
    bio: "王丹以细腻的水彩插画作品闻名，擅长捕捉日常生活中的温暖瞬间，出版多部插画集。",
    image: "/placeholder.svg?height=400&width=400",
  },
]

