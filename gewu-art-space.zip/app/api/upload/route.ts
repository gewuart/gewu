import { type NextRequest, NextResponse } from "next/server"
import { writeFile } from "fs/promises"
import { join } from "path"

// 这是一个示例API路由，用于处理文件上传
// 注意：在生产环境中，应该使用云存储服务而不是本地文件系统

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()

    // 获取表单数据
    const title = formData.get("title") as string
    const description = formData.get("description") as string
    const category = formData.get("category") as string
    const price = formData.get("price") as string
    const instructor = formData.get("instructor") as string
    const level = formData.get("level") as string

    // 获取文件
    const thumbnail = formData.get("thumbnail") as File
    const video = formData.get("video") as File | null

    if (!title || !description || !category || !price || !instructor || !level || !thumbnail) {
      return NextResponse.json({ error: "缺少必要字段" }, { status: 400 })
    }

    // 处理缩略图上传
    if (thumbnail) {
      // 生成唯一文件名
      const thumbnailName = `${Date.now()}-${thumbnail.name}`
      const thumbnailPath = join(process.cwd(), "public/uploads/thumbnails", thumbnailName)

      // 将文件写入服务器
      const thumbnailBytes = await thumbnail.arrayBuffer()
      const thumbnailBuffer = Buffer.from(thumbnailBytes)
      await writeFile(thumbnailPath, thumbnailBuffer)

      // 保存缩略图路径
      const thumbnailUrl = `/uploads/thumbnails/${thumbnailName}`

      // 处理视频上传（如果有）
      let videoUrl = null
      if (video) {
        const videoName = `${Date.now()}-${video.name}`
        const videoPath = join(process.cwd(), "public/uploads/videos", videoName)

        const videoBytes = await video.arrayBuffer()
        const videoBuffer = Buffer.from(videoBytes)
        await writeFile(videoPath, videoBuffer)

        videoUrl = `/uploads/videos/${videoName}`
      }

      // 在实际应用中，这里应该将课程信息保存到数据库
      // 例如：await db.courses.create({ ... })

      // 返回成功响应
      return NextResponse.json({
        success: true,
        course: {
          title,
          description,
          category,
          price,
          instructor,
          level,
          thumbnailUrl,
          videoUrl,
        },
      })
    }

    return NextResponse.json({ error: "缩略图上传失败" }, { status: 400 })
  } catch (error) {
    console.error("上传处理错误:", error)
    return NextResponse.json({ error: "服务器处理上传时出错" }, { status: 500 })
  }
}

