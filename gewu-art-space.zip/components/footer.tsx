import Link from "next/link"
import Image from "next/image"
import { Facebook, Instagram, Twitter, Youtube } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-white border-t">
      <div className="container mx-auto py-12 px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <Link href="/" className="flex items-center space-x-2 mb-4">
              <Image src="/logo.png" alt="格物艺术空间" width={40} height={40} />
              <span className="font-bold text-xl">格物艺术空间</span>
            </Link>
            <p className="text-gray-600 mb-4">探索艺术的无限可能，发现创作的独特魅力</p>
            <div className="flex space-x-4">
              <Link href="#" className="text-pastel-purple hover:text-pastel-purple/80 transition-colors">
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </Link>
              <Link href="#" className="text-pastel-pink hover:text-pastel-pink/80 transition-colors">
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </Link>
              <Link href="#" className="text-pastel-blue hover:text-pastel-blue/80 transition-colors">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </Link>
              <Link href="#" className="text-pastel-mint hover:text-pastel-mint/80 transition-colors">
                <Youtube className="h-5 w-5" />
                <span className="sr-only">YouTube</span>
              </Link>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-4 text-gray-800">快速链接</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/courses" className="text-gray-600 hover:text-pastel-purple transition-colors">
                  格学馆
                </Link>
              </li>
              <li>
                <Link href="/shop" className="text-gray-600 hover:text-pastel-purple transition-colors">
                  物品堂
                </Link>
              </li>
              <li>
                <Link href="/exhibitions" className="text-gray-600 hover:text-pastel-purple transition-colors">
                  展览
                </Link>
              </li>
              <li>
                <Link href="/artists" className="text-gray-600 hover:text-pastel-purple transition-colors">
                  艺术家
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-4 text-gray-800">帮助中心</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/faq" className="text-gray-600 hover:text-pastel-purple transition-colors">
                  常见问题
                </Link>
              </li>
              <li>
                <Link href="/shipping" className="text-gray-600 hover:text-pastel-purple transition-colors">
                  配送政策
                </Link>
              </li>
              <li>
                <Link href="/returns" className="text-gray-600 hover:text-pastel-purple transition-colors">
                  退换政策
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-gray-600 hover:text-pastel-purple transition-colors">
                  隐私政策
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-4 text-gray-800">联系我们</h3>
            <address className="not-italic text-gray-600 space-y-2">
              <p>北京市朝阳区艺术区A座101</p>
              <p>电话: 010-12345678</p>
              <p>邮箱: info@gewu-art.com</p>
              <p>周一至周五: 9:00 - 18:00</p>
              <p>周六至周日: 10:00 - 16:00</p>
            </address>
          </div>
        </div>

        <div className="border-t border-gray-200 mt-12 pt-8 text-center text-gray-500 text-sm">
          <p>© {new Date().getFullYear()} 格物艺术空间. 保留所有权利.</p>
        </div>
      </div>
    </footer>
  )
}

