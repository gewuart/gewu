"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { ChevronDown, Menu, Search, ShoppingBag, User } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useTheme } from "@/components/theme-provider"
import { useMobile } from "@/hooks/use-mobile"

const navItems = [
  {
    name: "格学馆",
    href: "/courses",
    hasDropdown: true,
    dropdownItems: [
      { name: "在线课程", href: "/courses" },
      { name: "素材库", href: "/resources" },
    ],
  },
  { name: "物品堂", href: "/shop" },
  { name: "展览", href: "/exhibitions" },
  { name: "艺术家", href: "/artists" },
  { name: "关于我们", href: "/about" },
]

export default function Header() {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false)
  const isMobile = useMobile()
  const { theme, setTheme } = useTheme()

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white shadow-sm">
      <div className="container mx-auto flex h-16 items-center justify-between px-4 md:px-6">
        <div className="flex items-center">
          <Link href="/" className="flex items-center">
            <Image src="/logo.png" alt="格物艺术空间" width={40} height={40} className="mr-2" />
            <div className="flex flex-col">
              <span className="text-lg font-bold leading-tight">格物</span>
              <span className="text-lg font-bold leading-tight">艺术</span>
            </div>
          </Link>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex md:items-center md:space-x-8">
          {navItems.map((item) => (
            <div key={item.name} className="relative">
              {item.hasDropdown ? (
                <div
                  className="flex items-center cursor-pointer"
                  onMouseEnter={() => setIsDropdownOpen(true)}
                  onMouseLeave={() => setIsDropdownOpen(false)}
                >
                  <Link href={item.href} className="text-base font-medium transition-colors hover:text-pastel-purple">
                    {item.name}
                  </Link>
                  <ChevronDown className="ml-1 h-4 w-4" />

                  {isDropdownOpen && (
                    <div className="absolute top-full left-0 mt-1 w-40 bg-white shadow-md rounded-lg overflow-hidden z-50">
                      {item.dropdownItems?.map((dropdownItem) => (
                        <Link
                          key={dropdownItem.name}
                          href={dropdownItem.href}
                          className="block px-4 py-2 text-sm hover:bg-pastel-purple/10 hover:text-pastel-purple"
                        >
                          {dropdownItem.name}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <Link href={item.href} className="text-base font-medium transition-colors hover:text-pastel-purple">
                  {item.name}
                </Link>
              )}
            </div>
          ))}
        </nav>

        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="icon"
            aria-label="搜索"
            className="text-gray-700 hover:text-pastel-purple hover:bg-pastel-purple/10"
          >
            <Search className="h-5 w-5" />
          </Button>

          <Button
            variant="ghost"
            size="icon"
            aria-label="购物车"
            className="text-gray-700 hover:text-pastel-purple hover:bg-pastel-purple/10"
          >
            <ShoppingBag className="h-5 w-5" />
          </Button>

          <Button
            variant="ghost"
            size="icon"
            aria-label="用户"
            className="text-gray-700 hover:text-pastel-purple hover:bg-pastel-purple/10 md:hidden"
          >
            <User className="h-5 w-5" />
          </Button>

          <Button className="bg-pastel-purple text-white hover:bg-pastel-purple/90 rounded-full hidden md:flex">
            登录
          </Button>

          {/* Mobile Menu */}
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
                <span className="sr-only">打开菜单</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="bg-white">
              <div className="flex items-center mb-8 mt-4">
                <Image src="/logo.png" alt="格物艺术空间" width={40} height={40} className="mr-2" />
                <div className="flex flex-col">
                  <span className="text-lg font-bold leading-tight">格物</span>
                  <span className="text-lg font-bold leading-tight">艺术</span>
                </div>
              </div>
              <nav className="flex flex-col space-y-6">
                {navItems.map((item) => (
                  <div key={item.name}>
                    {item.hasDropdown ? (
                      <div className="space-y-3">
                        <Link
                          href={item.href}
                          className="text-lg font-medium transition-colors hover:text-pastel-purple"
                        >
                          {item.name}
                        </Link>
                        <div className="pl-4 space-y-3 border-l border-gray-200">
                          {item.dropdownItems?.map((dropdownItem) => (
                            <Link
                              key={dropdownItem.name}
                              href={dropdownItem.href}
                              className="block text-base text-gray-600 hover:text-pastel-purple"
                            >
                              {dropdownItem.name}
                            </Link>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <Link href={item.href} className="text-lg font-medium transition-colors hover:text-pastel-purple">
                        {item.name}
                      </Link>
                    )}
                  </div>
                ))}
              </nav>
              <div className="mt-8 pt-6 border-t border-gray-200">
                <Button className="bg-pastel-purple text-white hover:bg-pastel-purple/90 rounded-full w-full">
                  登录
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}

